# Database

For some people, databases can be a daunting thing. Club Starter Kit needs to make databases easier.


## The default configuration
By default, the database is in the App_Data folder and is attached to the SQLExpress server at runtime. If you want to change this, take a look at the following sections


## Publishing the database
You have two options when publishing your database to a hosting provider. 

1) You can run our scripts
2) You can use the "[Database Publishing Wizard](http://www.microsoft.com/downloads/details.aspx?familyid=56e5b1c5-bf17-42e0-a410-371a838e570a&displaylang=en)" in Visual Studio (not Express)

If you are going to run the scripts, run the "Schema" script against your database first. 

If you don't want the test data added in, don't run the "Data" script. If you do, however, run it.