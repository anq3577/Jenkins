## Zack Owens

Hi. I'm the coordinator for the Club Starter Kit project. Most of the archeitetual things and most of the development comes from my home computer :)

I co-own a web design and software development firm (see link bellow). My free time is usually split between Club Starter Kit and my job.

I'll probably post some more about myself later. I have some more work to do on the project! 


#### Links

[My company (EagleEnvision.NeT)](http://www.eagleenvision.net/)
[My company blog](http://blogs.eagleenvision.net)
[ASP.NET Weblog](http://weblogs.asp.net/zowens/)
[My other project... needs work (SchoolCORE)](http://codeplex.com/SchoolCORE)


(OTHERE PROJECT MEMBERS: Go ahead and create yourself a wiki page that tells more about you!)