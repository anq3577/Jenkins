# Content Pages

Sometimes, you just want to create a simple page with text on it. In conjunction with the CMS code provided in the starter kit, you can also add your own pages.

The only thing you need to do is navigate to ~/content/[YOUR_PAGE_NAME](YOUR_PAGE_NAME).aspx

This will create the page... sort of.

What really happens is your request is thrown in a URL rewriter which tosses it to ~/contentpages/page.aspx?page=[YOUR_PAGE_NAME](YOUR_PAGE_NAME). Then it takes the query string and make the Section of the CMS code to be the page name.

Confused? Ok... just navigate to ~/content/[YOUR_PAGE_NAME](YOUR_PAGE_NAME).aspx to create your own page ;)