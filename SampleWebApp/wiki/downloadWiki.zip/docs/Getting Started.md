# Getting Started

Basically, all you need to do to get started is the change the web.config in a few places. I recommend regenerating the templates as well.


## 1 - EDIT YOUR CONNECTION STRING!

If you are using the express version, open the ConnectionStrings.config and **CHANGE YOUR CONNECTION STRING** to map to your particular location.

If you are using the Standard version (only difference being that Standard can't run in the Express editions of Visual Studio) you need to make 2 edits. FIRST go to the ConnectionString.config in the website. Edit the connection string. Next go to the App.Config in the ClubStarterKit.Data project. Edit that connection string. 

## 2 - Edit the application settings
Open the web.config file in the root of the website. You have one choice to make in the app settings, whether or not you want to host your photos on the file system or your database.

Do not make edits to the FCKeditor:UserFilesPath or FCKeditor:BasePath settings.

To edit the Name that appears at the top of the site, or the slogan, address, copyright, etc. Open your website and log in as an administrator. Now go to the home page and click "Edit Settings".

## 3 - Edit the mail settings
The ASP.NET Membership provider looks at the <system.net> section of the web.config file to look for the properties of your SMTP settings. Edit the mail settings from lines 231-237. You also need to edit the SMTP settings as described in the previous section.

## 4 - Generating SubSonic DAL classes
I **highly** recommend generating up the DAL classes once again. This ensures that your configuration of the database was sucessful. Take a look at the following for instructions on regenerating the DAL classes.

[Standard Version](http://www.codeplex.com/ClubStarterKit/Wiki/View.aspx?title=SubSonic%20-%20Standard%20Version)
[Express Version](http://www.codeplex.com/ClubStarterKit/Wiki/View.aspx?title=SubSonic%20-%20Express%20Version&referringTitle=Documentation)

That's it! You can now run your site!