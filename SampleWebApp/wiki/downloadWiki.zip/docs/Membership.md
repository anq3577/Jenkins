# Membership

ASP.NET 2.0 has an extremely nice and flexible Membership Provider. The Club Starter Kit has used this default provider and use it in the various areas of the site.


## Login
You can either login from the default page or by clicking "Membership" at the top.


## Register
Click "Membership" at the top and click "Register" on the 3rd pane in the middle. Follow the instructions and **COMPLETE STEP 2**.


## Roles
We have put in some roles by default that do a few things. Here is an explaination of what each role can do

### Anonymous Users 
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* View Statistics


### Logged in users 
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* Comment on blog post
* Post in the forums
* RSVP to an event
* Receive newsletter
* View Statistics


### Blogger
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* Comment on blog post
* Post in the forums
* RSVP to an event
* Receive newsletter
* View Statistics
* Add blog post
* Delete blog post
* Delete user comment


### Editor
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* Comment on blog post
* Post in the forums
* RSVP to an event
* Receive newsletter
* View Statistics
* Edit CMS text


### GameRecorder
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* Comment on blog post
* Post in the forums
* RSVP to an event
* Receive newsletter
* View Statistics
* Edit game score
* Edit person's stats


### Moderator
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* Comment on blog post
* Post in the forums
* RSVP to an event
* Receive newsletter
* View Statistics
* Recieve emails for moderation
* Delete forum posts under their control


### Administrator
* View event
* View news
* View forum posts (including comments)
* View photos and photo albums
* View blog post and blog comments
* View CMS pages
* Comment on blog post
* Post in the forums
* RSVP to an event
* Receive newsletter
* View Statistics
* Edit/Delete users
* Send newsletter
* Edit Site settings
* Use the AutoScaffold for quick database fixes