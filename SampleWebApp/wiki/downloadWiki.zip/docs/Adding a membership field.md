# Adding a membership field

Sometimes you just want to add a extra membership field users must give to become members. For this example, we will the field FavoriteColor.


## Step 1: Add to the database
* Add a field in the MemberInfo Table (For this ex, I will use favoritecolor as a varchar(50)
* Open your memberinfo table and enter some favoritecolor value for the existing names


## Step 2: Configure DAL
Now you need to regenerate your SubSonic DAL classes.


## Step 3: Make page edits

### Member Details
* Open Member/Details.aspx
* Go into design mode and add a row in the member details table
* Make a textbox and call it fcolor (It is recommended that your add a validator. This field IS required)
* Add a new line AFTER line 51 (line 51 reads qry.AddUpdateSetting(MemberInfo.Columns.Newsletter, NewsletterCheck.Checked))
* On the new line (which should be 52), add this: qry.AddUpdateSetting(MemberInfo.Columns.Favoritecolor, fcolor.Text))
* Make line 57 (which now reads this: MemberInfo.Insert(Addr.Text, Phone.Text, fname.Text, lname.Text, Nothing, user.ProviderUserKey(), NewsletterCheck.Checked)) say this: MemberInfo.Insert(Addr.Text, Phone.Text, fname.Text, lname.Text, Nothing, user.ProviderUserKey(), NewsletterCheck.Checked, fcolor.Text)
* Add a line after line 87. Put the following onto the new line: fcolor = MemInfo.Favoritecolor

### Registration
* Open Member/register.aspx
* Add a row bellow in the table and make a textbox called fcolor (It is recommended that your add a validator. This field IS required).
* Make line 27 read MemberInfo.Insert(Addr.Text, Phone.Text, fname.Text, lname.Text, Nothing, CType(user.ProviderUserKey, Guid), NewsletterCheck.Checked, fcolor.Text)
* Under line 22, add the following: fcolor.Enabled = False
* Under line 63, add the following: fcolor.Enabled = True

## Step 4: Save and run