# Troubleshooting AJAX

Here's the thing, ASP.NET AJAX sometimes doesn't like to work. The UpdatePanels just don't want to do their jobs.

You might get weird errors talking about JavaScript. This is caused by the ASP.NET UpdatePanels.

To fix this, take out the UpdatePanel causing you problems.

To do this, remove this line before the content:

{{ 
<asp:UpdatePanel ID="UpdatePanel1"  RenderMode="Inline" runat="server" >
<ContentTemplate>
}}

And these lines after the content.

{{
</ContentTemplate>
</asp:UpdatePanel>
}}

This isn't a pretty fix, but it makes it work again.