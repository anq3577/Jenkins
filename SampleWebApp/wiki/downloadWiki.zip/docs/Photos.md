# Photos

The photo architecture in the Club Starter Kit is quite extensive. The images are stored in the database and are taken out dynamically.


## Add Photo Album
Once logged on as an administrator, click "Photos" at the top. Click "New Album". Enter your album name and click "Add Album".


## Add Photos to an Album
Open your desired album. Under the heading "Upload Photos", select your file and image title and click "Upload".


## View Photo Album
To view a photo album, click "photos" at the top. Select the album title. Now select your picture from the left sidebar. This will show the larger image in the middle content area.


## Delete Photo Album
After following the step labeled "View Photo Album", click "Delete Album".


## Edit Album Properties
After following the step labeled "View Photo Album", click "Edit Album". Make your changes and click Apply.