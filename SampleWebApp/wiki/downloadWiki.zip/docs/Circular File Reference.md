# Circular file refference

Sometimes, you might get a "Circular File Reference" error once you try to run your website from Visual Studio.

IGNORE IT! Just try building it again. It should work.

If anyone knows how to fix this, send me an email ([zowens@eagleenvision.net](mailto:zowens@eagleenvision.net)).