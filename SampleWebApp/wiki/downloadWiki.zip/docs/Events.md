# Events

The events module in the Club Starter Kit is a real innovation on the ASP.NET starter kits. The events module adds rich experiences such as RSVP and cool controls such as the calendar.


## Add events
To add events, click on the "Event" link at the top. Now click "New Event". To read more about RSVP, see the section about RSVP down below.


### Add Location
Sometimes there are situations where you need to add a location to an event. With the Club Starter Kit, you can easily achieve this. When you are in Edit or Add mode, click "Add Location". Follow the instructions.


## View Events
Click "Events" at the top. Click the event title.

From here, you can read the event, click the "Add to my personal calendar" link to add to your outlook calendar, and view a printable version of the event.


## Edit event
Follow instructions on "View Events" and click "Edit" (Must be an administrator).


## Delete Event
Follow instructions on "View Events" and click "Delete" (Must be an administrator).


## Add Downloads
Follow instructions on "View Events" and click "Downloads" (Must be an administrator). Follow the simple instructions on that page to add downloads to that particular event.


## Adding RSVP
To add RSVP to your website, you need to make some quick changes during the addition or editing of events.

First, check the box stating that you do want RSVP (if you do not, uncheck it).

Next, specify the number of max. users that can attend (Use -1 for unlimited users). 

Your done!


## RSVP-ing to an event
To RSVP, login. Next open the event with which you will be RSVP-ing to.

Look under the RSVP heading. There should be a textbox asking how many people you will be bringing (including yourself). Then press "Yes". 

It is that simple!


## Send an email to the RSVP-ed members
As an administrator, click "Send Email" after following the "View Event" instructions. Follow the instructions and click "Send Email".