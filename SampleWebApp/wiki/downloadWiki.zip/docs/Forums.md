# Forums

With the Club Starter Kit, we have added the forums created by Mark Bracewell. We have added a few tweaks and modifications to his code.


## Administer areas
Once you are logged in as an administrator, click "Forums" at the top. Now click "Manage Forums". Use the grid to make edits or to delete sections. Use the "Add" form to add a forum section.

In the Manage Forums page, Administrators can also define the Moderator for that particular section. A moderator is a user in the role "Moderator".


## View a forum
Once you have added a forum area, click "Forums" at the top. Then click the title of the forum area.


## Add post
To add a post to a particular forum area, follow the "View a forum" instructions. Then click "New Thread", which should appear on the top right. Add your title, text, and whether or not you want to watch the thread. Then click "Post".


## View a forum post
Once you followed step "view a forum", click on a forum post. You will see the threaded forum with replies.

### Delete
Click "Delete" at the top right to delete a forum post if you are the moderator for thus said forum area.

### Lock
If you don't want any more replies, click "Lock Thread".

### Sticky
To make the post "sticky", meaning it will show up with the other sticky posts when you view the forum area, click "Make Sticky".

### Watch
To watch a particular thread for replies and be notified when there are replies, click "Watch Thread".

### Reply
To reply to a thread, click "Reply" under the entry with which you wish to reply.

### Quoted Reply
To reply to a thread and have its text quoted in your post, click "Quoted Reply" under the entry with which you wish to reply.

### Edit
To edit your own entry (or someone else's entry if you are a moderator), click "Edit" right under the text.

### Switch Views
You have two options when viewing a post: "Oldest First" or "Newest First". To change this option, use the dropdown.


## Forum Profile
Your forum profile contains your information about your life on the forums. It contains all sorts of stats such as the number of posts you have posted.

Your profile also contains your bio and signature. Your signature is show on all posts and all posts that you have created are updated with your current signature. To edit your bio and signature, go to ~/Membership/details.aspx.


## Mark All Read
Every time you read a forum post, it is marked that you have read thus said forum post in the database. To make all of the posts read so that you don't see highlighted sections (indicating that you have not read a post) click "Mark All Read" on the Forums homepage (Click "Forums" at the top).




### DISCLAIMER NOTICE

Copyright (c) 2006, Mark Bracewell (bracewell at wgg dot com)
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 
* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* The name Mark Bracewell may not be used to endorse or promote products derived from this software without specific prior written permission. 
* THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL MARK BRACEWELL BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 