# League Tracker

The League Tracker is as set of features that a sports club might use to track games, teams, and statistics. With Version 3 Beta 1, the League tracker makes its first debut!

## Hirearchy
The top most level is the season. It holds the teams and games of any particular season.

Games rely on Teams (2 teams).

Teams relies on PlayersInTeams.

PlayersInTeams relies on the Player table which identifies a given members as a player.

On the statistics side, the PlayersInStats table houses game stats info for players.


## Setup
The first thing you will want to do is add a season. You can do so by logging in as an administrator or GameReporter. Then go to "~/statisitics/default.aspx". Then click "New Season". 


## New Teams
To add a team, login as a GameReporter or Admin. Then click "New Team" on the same ~/statistics/default.aspx page.


## New Game
Once you have added the teams necessary, click "New Game" on the ~/statistics/default.aspx page.


## Edit Game score
Once you have added a game, click the game under the "Upcoming Games" section or "Scoreboard" section. Then click "Edit Score" at the top.


## Edit Individual Stats
Under the same game page, click "Edit" next to the player's name.




**MORE TO BE ADDED SHORTLY AFTER BETA 1**