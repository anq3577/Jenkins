# Blogs

Blogging is a popular trend with new sites. The Club Starter Kit adds a simple blogging system to your club's website.


## Add a blog post
Once you are logged in as an administrator, click "Blogs" at the top. Now click "New Post". Enter your title and text and click "Add Blog Post".


## View a blog post
Click "Blogs" at the top. Now click the title.

If you need a larger time span of posts to view from, click "Blog Post Archieve". Then click the title.


## Add a comment
After following the "View a blog post" step and logging in as a user, you should see the heading "Add Comment". Enter your text and click "Add Comment".


## Delete a comment
As an administrator, you can click "Delete" under a particular comment.


## Delete a post
As an administrator, you can click "Delete Post" under the blog post text.