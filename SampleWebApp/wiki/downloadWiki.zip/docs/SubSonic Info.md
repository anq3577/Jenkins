# SubSonic

[SubSonic](http://codeplex.com/actionpack) is a "toolset that helps a website build itself". We will be using it because of it's data access layer generation. We have chosen SubSonic because it is open source and it really has a nice toolset for all database needs. LINQ and Project Jasper were both considered but they do not even come close to the functionality SubSonic offers. 


## Configuration
We have decided to add an aditional project with the name and namespace ClubStarterKit.Data. This will host all the generated SubSonic DAL files. It will also have some files that extend the templates that SubSonic provides. To have the files generated, see the "Configure Generation" section. The website will now be under the namespace ClubStarterKit.Web.


## What about Express Edition!!!!
We decided to use the external project for the DAL because of organization. We could have chosen to use the SubSonic build provider. At the major betas and releases, we will put out a "Express Edition" build that has either the classes that are generated in the website or have the site use the SubSonic build provider. To use the source in the source code using Visual Studio Express, you will need install VB Express, do your magic with the ClubStarterKit.Data project, build the ClubStarterKit.Data project, then take the DLL and put it in the bin directory of the ClubStarterKit.Web project. For your generation step, do the "Configure Generation" in the VB IDE.

I highly recommend you use, at the very least, Standard edition. [You can get it free if you watch some webcasts or something like that.](http://www.microsoft.com/business/vb2005upgrade/default.mspx)


## Configure Generation
SubSonic comes with a nice generator command line tool called "SubCommander". After you [download](http://www.codeplex.com/actionpack/Release/ProjectReleases.aspx?ReleaseId=5177) and run the SubSonic 2.0.3 installer, you will need to do the following:

1) Open Visual Studio Standard/Professional/Team Suite or VB Express
2) Click on "External Tools" under the "Tools" menu. 
3) Click add
4) Enter a title
5) Navigate to the {$Program Files$}/SubSonic/SubSonic 2.0.1/sonic.exe file for "Command" (replace {$Program Files$} with your Program Files directory)
6) Put in the following for the arguments: generate /out Generated /lang vb
7) MAKE SURE initial directory is set to Project Directory or the text in the textbox is $(ProjectDir)
8) Prompt for arguments, Use Output window
9) Click ok
10) Go to tools and click the command


## Database
Make sure that if you change your connection string to your database, change the connection string in ClubStarterKit.Data/app.config


## IMPORTANT
**Change the connection string of the database in the app.config once you get the starter kit.** It is referenced to the location on my machine. YOU NEED TO CHANGE IT TO FIT YOUR MACHINE!


## Support
I would be **MORE THAN HAPPY** to entertain questions about SubSonic and our implementation of it. Send me an email: [zowens@eagleenvision.net](zowens@eagleenvision.net)