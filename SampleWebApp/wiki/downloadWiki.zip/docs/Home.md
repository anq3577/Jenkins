# ClubStarterKit Open Source Project

Welcome to the homepage for the ClubStarterKit open source project on codeplex. Back when Visual Studio 2005 was being built, Microsoft built a collection of starter kits that would give developers great sample applications to learn how to develop software or to simply get something running without a lot of headache. The goal of ClubStarterKit open source is to extend the original Microsoft ClubStarterKit that was released by Microsoft. By using emerging technology and new standard practices, ClubStarterKit will evolve into a community-driven project that anyone can download, extend, and publish with minimal ease.

## Current Version

[release:36375](release_36375)

Currently, there is momentum to release a brand new ClubStarterKit code base. The new code base is written in C# and has a clear distinction between the layers of the application. It also features a modular approach to building the ClubStarterKit website. A developer will be able to choose from a  new different data access providers and database servers. Written entirely in ASP.NET MVC 2, Visual Studio 2010, and ASP.NET 4.0, ClubStarterKit's 3.0 code base will be a significant shift from versions past. For the first time, this starter kit will present developers with a concrete example of some of the best practices that are currently in use in other major projects. It is the goal of ClubStarterKit to provide a high quality sample as well as a usable website for those who simply want to get an organization website out onto the web.

The current version is [release:36375](release_36375). This contains the new code base. Read more about the current release. 

NOTE: Because this is a preview, the documentation isn't quite ready. As we come closer to version 3 final, more documentation will be released to the codeplex site under the documentation tab.

## A Call To Action

Your task is to use the kit and give us your feedback! We are always taking feature requests and bug fixes. This project wouldn't be what it is without the support of the community. So PLEASE tell us what you like, what you hate, and what could be better. We're here to build a _community_ project... and _YOU_ are a part of that community. 

## About 

ClubStarterKit open source is a project sponsored by [eagleenvision.net](http://www.eagleenvision.net) and is primarily the work of Zack Owens. For support options, please email Zack Owens at [zowens@eagleenvision.net](mailto:zowens@eagleenvision.net). 

![eagleenvision.net logo](Home_current logo.png|http://www.eagleenvision.net/)

## News

{rss:url=http://weblogs.asp.net/zowens/rss.aspx?Tags=ClubStarterKit&AndTags=1,max=3,titlesOnly=true}

NOTE: We are in no way connected with Microsoft at this point... we just use their platform.