# News

Every Club has news to share. With the Club Starter Kit, adding, editing, and viewing news is a seamless experience


## Add News
To add news, you must be logged in as an administrator. Now click "News" at the top. Click the "add news" button.

Follow the simple form and input your desired values. REMEMBER to put in a title and a description.


## View News
To view news, click "News" at the top. Now click the title of the article. This will bring you to the article view page.


## Edit News
Follow the steps from "View News". Click the edit button. (To edit news, you must be logged in as an Administrator).


## Delete News
Follow the steps from "View News". Click on the delete button. (To delete news, you must be logged in as an Administrator).


## Downloads
Follow instructions on "View News" and click "Downloads" (Must be an administrator). Follow the simple instructions on that page to add downloads to that particular article.