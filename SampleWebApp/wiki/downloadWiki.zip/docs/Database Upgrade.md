# Upgrade Instructions

To upgrade your database from v2 FINAL to v3 Beta 1, do the following:

1) BACKUP YOUR DATABASE!
2) Run the Upgrade script (in the upgrade download)
3) Open the TableChanger app in Visual Studio 2005 Standard, Professional, Team Suite, or VB 2005 Express.
4) Open the app.config and map the connection string to your database
5) Run the app and click the button.
6) YOU'RE DONE!