# Version 3 Beta 1 
* Full BLL
* SubSonic
* Poll Control
* League Management
* Rearchitected Forums
* Better User Administration
* Improved Photo System
	* Photos on file system
* Improved Blogging system
	* Member name from Membership Key
	* User's personal blog


# Version 3 Beta 2/RC/Final
* Better User Administration
* Visual Studio 2008 Solution File
* Centralized Roles
* BUG FIXES!
* Others per user feedback 


# Version 4
* Improved Photo System
	* Slideshow
	* Paged Albums
	* Commenting
	* Linking 
* Improved Blogging system
	* Edit Blog
	* User's personal blog
* Selectable monthly, weekly, or daily calendar views
* ASP.NET's MVC Framework
* ASP.NET 3.5 (Visual Studio 2008)
* Wiki
* Others per user feedback