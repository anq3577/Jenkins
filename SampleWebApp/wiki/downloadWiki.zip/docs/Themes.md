# Themes

ASP.NET 2.0 offers a great way to have different styles. ASP.NET 2.0 themes allow modularity and control over your site's theme.


## Change themes
To change themes, it takes a little edit in the web.config. Look for the pages section of the web.config (Line 130 on the default kit) where it says "Theme", change it to a theme referenced in the "App_Theme" folder. I would use the same case as listed in the theme folder. Then you save it. That's it!


## Make a theme
Copy the "ClubSite" theme folder and make your own folder. Make all your edits to the new folder's CSS, skin, and image files.