# SubSonic DAL - Express Version

## How this is configured
Standard version was built as the optimal route for users with Standard, Professional, or Team Suite editions of Visual Studio 2005. Express, on the other hand, was built with the Visual Studio Express versions in mind. Express ships with something the standard version do not ship with, the generator page.

The functionality of the Starter Kit is NOT different in any way other than the way the DAL classes are generated.

## Generation
Open your website up to the ~/dev/generators.aspx page. Select your output directory (**It MUST be a file directory**), your language, click "All" under tables, click "All" under views, and click Generate.

See... that wasn't so bad!

## I NEED HELP!
Ok, send me an email then! [zowens@eagleenvision.net](mailto:zowens@eagleenvision.net).