# Content Management System

In the Club Starter Kit, we provide you with a quick an easy content management system.


## Edit content
To edit content, click the pencil icon if you see it (you must be logged in as an "Editor"). Edit your text using the editor and submit.


## Put a CMS control on a page

First, put this at the top of the page under the page atributes.

{{ <%@ Register Src="~/UserControls/WebContent.ascx" TagName="WebContent" TagPrefix="Club" %> }}

Now, put this in the page where you want the CMS area to be.

{{ <Club:WebContent ID="WebContent1" runat="server" /> }}

I personally like to add a "Section" to the control. If you were to do that, your control would look like this:

{{ <Club:WebContent ID="WebContent1" runat="server" Section="foo" /> }}