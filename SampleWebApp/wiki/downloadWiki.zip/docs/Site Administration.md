# Site Administration


## Manage Users
Once you are logged in as an administrator, click "Manage Users". Next to all the members, the links "Edit" and "Delete" appear. With edit, you can edit membership roles. With delete, you will delete the member and their corresponding information.


## Send a newsletter
Logged in as an administrator, click "Send Email". Then put in your text, subject and attachments and click the "Send Email" button.