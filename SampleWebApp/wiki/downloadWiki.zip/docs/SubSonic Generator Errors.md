# SubSonic Generator Error

Sometimes your generation fails. What has most likely happened is that ClubSK.mdf most likely doesn't see that your are me. What you should do is delete the ClubDB_log file and open up your database in the Database explorer. Then try your SubSonic generation again.