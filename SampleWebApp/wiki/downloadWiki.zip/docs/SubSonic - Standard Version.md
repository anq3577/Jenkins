# SubSonic DAL - Standard Version

## How this is configured
Standard version was built as the optimal route for users with Standard, Professional, or Team Suite editions of Visual Studio 2005. The way Standard Edition is configured is the only difference from the Express Version.

The way Standard is configured is for you to use the SubSonic command line tool ("SubCommander" as it is called). See "Setup SubCommander" for details on settings that up.

Anyways, this version was configured for a 1 push of a button to generate Data Access classes in secconds. 

## Settings up SubCommander
First, you need to dowload SubSonic's setup package. For ClubStarterKit v3 Beta 1, we will use SubSonic 2.0.3. After you run the setup wizard, you should now see all the SubSonic bits (SubSonic.DLL, SubCommander, etc) in the Program Files\SubSonic\SubSonic 2.0.3\ directory.

Next, fire up Visual Studio. Now, open up Tools --> External Tools. Click Add. Enter a name (something like SubSonic Gen). Now map C:\Program Files\SubSonic\SubSonic 2.0.3\SubCommander\sonic.exe to the command field (if you have your default drive set to something other than C:\, change it :) ).

Now put this as the arguments:

generate /out Generated /lang vb

MAKE SURE initial directory is set to Project Directory or the text in the textbox is $(ProjectDir)

Now click "Use Output window". Now click OK. 


## Generation
Once you have the generator setup, all you need to do is go to Tools and click your SubSonic Generator command.

## I NEED HELP!
Ok, send me an email then! [zowens@eagleenvision.net](mailto:zowens@eagleenvision.net).